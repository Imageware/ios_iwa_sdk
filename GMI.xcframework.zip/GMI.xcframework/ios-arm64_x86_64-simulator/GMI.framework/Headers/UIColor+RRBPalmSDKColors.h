//
//  UIColor+PalmIDColors.h
//  PalmSDK-iOS
//
//  Created by An on 10/3/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (RRBPalmSDKColors)

+ (UIColor *)rrbPalmSDK_redColor;
+ (UIColor *)rrbPalmSDK_greenColor;
+ (UIColor *)rrbPalmSDK_blueColor;
+ (UIColor *)rrbPalmSDK_greyColor;

@end

NS_ASSUME_NONNULL_END
