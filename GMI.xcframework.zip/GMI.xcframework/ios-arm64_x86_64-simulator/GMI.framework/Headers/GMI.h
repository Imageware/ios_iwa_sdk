//
//  GMI.h
//  GMI
//
//  Created by ImageWare Systems, Inc on 12/20/18.
//

#import <UIKit/UIKit.h>

#if TARGET_IPHONE_SIMULATOR
#else
#import <RRBPalmSDK2/RRBPalmSDK2.h>
#endif
FOUNDATION_EXPORT double GMIVersionNumber;

FOUNDATION_EXPORT const unsigned char GMIVersionString[];

