//
//  UIBarButtonItem+RRBPalmSDKNavigation.h
//  PalmSDK-iOS
//
//  Created by An on 12/16/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

@import UIKit;

NS_ASSUME_NONNULL_BEGIN

@interface UIBarButtonItem (RRBPalmSDKNavigation)

+ (instancetype)rrbPalmSDK_backButtonForTarget:(id)target action:(SEL)selector;

@end

NS_ASSUME_NONNULL_END
