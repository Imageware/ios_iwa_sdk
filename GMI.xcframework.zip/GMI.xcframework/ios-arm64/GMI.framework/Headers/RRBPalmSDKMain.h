//
//  RRBPalmSDK.h
//  PalmSDK-iOS
//
//  Created by An on 12/11/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//
@import UIKit;

#import "RRBPalmSDKDecoder.h"
#import "RRBPalmSDKWorkflow.h"

NS_ASSUME_NONNULL_BEGIN

/**
 Constant used to provide status information on decoder creation.
 */
typedef NS_ENUM(NSInteger, RRBPalmSDKDecoderStatus) {
    /// No decoder available
    RRBPalmSDKDecoderStatusMissing,
    /// Decoder is created, but not ready yet
    RRBPalmSDKDecoderStatusConnecting,
    /// Decoder is ready
    RRBPalmSDKDecoderStatusReady,
    /// Decoder creation is failed
    RRBPalmSDKDecoderStatusFail
};

/**
 Create decoder delegate.
 */
@protocol RRBPalmSDKCreateDecoderDelegate
/**
 Notifies the delegate that decoder is ready for work.
 */
- (void)handleDecoderDidCreated;

/**
 Notifies the delegate that error is occuring during decoder creation.
 @param error error
 */
- (void)handleDecoderError:(NSError *)error;
@end

/**
 Helper class to store global decoder.
 */
@interface RRBPalmSDK : NSObject <RRBPalmSDKDecoderHandler>

/**
 Return decoder
 @returns decoder or nil if decoder is not ready yet
 */
+ (_Nullable id<RRBPalmSDKDecoder>)decoder;

/**
 Get decoder status
 @returns decoder status
 */
+ (RRBPalmSDKDecoderStatus)decoderStatus;

/**
 Create decoder for license id and set it for global usage with SEL(decoder)
 
 @param licenseID license id
 @param delegate create decoder delegate for handling decoder status
 */
+ (void)createDecoderWithLicenseID:(NSString *)licenseID delegate:(id<RRBPalmSDKCreateDecoderDelegate>)delegate;

/**
 Create cloud decoder for license id and set it for global usage with SEL(decoder)
 
 @param licenseID license id
 @param serverURL server
 @param delegate create decoder delegate for handling decoder status
 */
+ (void)createDecoderWithLicenseID:(NSString *)licenseID serverURL:(NSURL *)serverURL delegate:(id<RRBPalmSDKCreateDecoderDelegate>)delegate;


/**
 Destroy global decoder
 */
+ (void)destroyDecoder;

@end
//
NS_ASSUME_NONNULL_END
