//
//  RRBPalmSDKUser-Private.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 5/9/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import "RRBPalmSDKUser.h"

typedef NS_ENUM(NSInteger, RRBPalmSDKUserPalmType) {
    RRBPalmSDKUserPalmTypeLeft = 0,
    RRBPalmSDKUserPalmTypeRight = 1,
};

@protocol RRBPalmSDKPersistentDataManager;

@class RRBPalmSDKModelInfo;

@interface RRBPalmSDKUserInternal : RRBPalmSDKUser <NSCoding>

- (instancetype)initAsDefault;

@property (nonatomic, strong) id<RRBPalmSDKPersistentDataManager> persistentDataManager;

// unique id of user instanse defines folder name where user's data stored
@property (nonatomic, strong, readonly) NSString *uniqueID;

// provided 'real' user properties
@property (nonatomic, strong) NSString *username;

// if non-nil used to control uniqueness of users
@property (nonatomic, strong) NSString *userUniqueID;

@property (nonatomic, strong) NSData *passcodeData;

@property (nonatomic, assign) BOOL livenessEnabled;

// called once on user registration
- (void)performSetup;

- (BOOL)hasLeftPalmModelData;
- (BOOL)hasRightPalmModelData;
- (BOOL)hasPasscodeData;

- (BOOL)hasModelDataForPalmWithIndex:(NSUInteger)index;
- (RRBPalmSDKModelInfo *)modelInfoForPalmWithIndex:(NSUInteger)index;
- (void)setModelInfo:(RRBPalmSDKModelInfo *)modelInfo forPalmWithIndex:(NSUInteger)index;
- (void)removeModelDataForPalmWithIndex:(NSUInteger)index;

- (void)removeAllData;

@end
