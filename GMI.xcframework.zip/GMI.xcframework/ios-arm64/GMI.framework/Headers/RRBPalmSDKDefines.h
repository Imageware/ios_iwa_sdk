//
//  RRBPalmSDKDefines.h
//  PalmSDK-iOS
//
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#ifdef __cplusplus
#define RRBPALM_EXTERN		extern "C" __attribute__((visibility ("default")))
#else
#define RRBPALM_EXTERN	        extern __attribute__((visibility ("default")))
#endif

