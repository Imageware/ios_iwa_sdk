//
//  RRBPalmSDKEnrollmentViewController.h
//  PalmSDK-iOS
//
//  Created by An on 11/29/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

@import UIKit;

#import "RRBPalmSDKCamera.h"

NS_ASSUME_NONNULL_BEGIN

@protocol RRBPalmSDKUserProtocol;
@protocol RRBPalmSDKDecoder;
@class RRBPalmSDKModelInfo;

/**
 Completion handler block signature
 */
typedef void (^RRBPalmSDKEnrollPalmsViewControllerCompletionHandler)(NSArray<RRBPalmSDKModelInfo *> * __nullable models, NSError * __nullable error);

@interface RRBPalmSDKEnrollPalmsViewController : UIViewController

/**
 Create view controller with [RRBPalmSDK decoder].
 
 @param cameraPosition camera position
 @param completionHandler completion handler
 */
- (instancetype)initWithCameraPosition:(RRBPalmSDKCameraPosition)cameraPosition completionHandler:(RRBPalmSDKEnrollPalmsViewControllerCompletionHandler)completionHandler;

/// Callback block called on completion
@property(nullable, nonatomic, copy) RRBPalmSDKEnrollPalmsViewControllerCompletionHandler completionHandler;

/**
 Decoder. [RRBPalmSDK decoder] by default
 */
@property (nonatomic, weak) id<RRBPalmSDKDecoder> decoder;

/**
 Camera. Front camera by default
 */
@property (nonatomic) id<RRBPalmSDKCameraProtocol> camera;

/**
 Liveness setting. NO by default
 */
@property (nonatomic) BOOL livenessEnabled;

@end

NS_ASSUME_NONNULL_END
