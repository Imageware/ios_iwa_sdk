//
//  RRBPalmSDKModelID.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 6/26/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RRBPalmSDKModelID : NSObject <NSCoding>
@end


NS_ASSUME_NONNULL_END
