//
//  RRBPalmModelingViewController.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 5/2/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RRBPalmSDKAuthViewController.h"
#import "RRBPalmSDKModelInfo.h"

typedef void (^RRBPalmModelingViewControllerCompletionHandler)(RRBPalmSDKModelInfo * __nullable modelInfo, NSError * __nullable error);

@class RRBPalmSDKUserInternal;

@interface RRBPalmModelingViewController : UIViewController

@property(nullable, nonatomic, copy) RRBPalmModelingViewControllerCompletionHandler completionHandler;

@property (nonatomic) BOOL showHintForLeftPalm;
@property (nonatomic) BOOL showHintForRightPalm;

@property (nonatomic, strong) RRBPalmSDKUserInternal * _Nullable user;

@property (nonatomic) BOOL expectRecycling;
- (void)recycle;

@end
