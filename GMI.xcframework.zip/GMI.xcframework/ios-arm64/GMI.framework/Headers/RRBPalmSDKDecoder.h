//
//  RRBPalmSDKDecoder.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 4/26/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#include <Foundation/Foundation.h>

#include "RRBPalmSDKModelMatchResult.h"

NS_ASSUME_NONNULL_BEGIN

@class RRBPalmSDKModelID;
@class RRBPalmSDKModelInfo;

extern NSString *const kRRBPalmSDKExifRearFacingCameraFlag;
extern NSString *const kRRBPalmSDKExifActiveLightningFlag;

@protocol RRBPalmSDKDecoderHandler <NSObject>

@optional

- (void)handleDecoderDidCreated;

- (void)handlePalmDecoderError:(NSError *)error;

- (void)handleDidAddPalmInfoForModelID:(RRBPalmSDKModelID *)modelID;
/**
Handle remove result for removePalmInfoForModel and removePalmInfoForModelID calls

@param modelID removed modelID
*/
- (void)handleDidRemovePalmInfoForModelID:(RRBPalmSDKModelID *)modelID;

- (void)handleNoPalmDetected;

- (void)handleDetectedPalmAtPoints:(CGPoint)a b:(CGPoint)b  c:(CGPoint)c  d:(CGPoint)d;

- (void)handlePalmMatchingStarted;

- (void)handlePalmMatchingResult:(BOOL)matched;
/**
 Handle matching result with each model result
 
 @param matched match result
 @param results matching result for each model from startMatchingFor:withModels: NSArray
 */
- (void)handlePalmMatchingResult:(BOOL)matched modelMatchResults:(NSArray<RRBPalmSDKModelMatchResult *> *)results;

- (void)handlePalmModelingStarted;
- (void)handlePalmModelingInfo:(RRBPalmSDKModelInfo *)modelInfo;

- (void)handleLivenessResult:(BOOL)result;
- (void)handleLivenessStarted;

- (void)passMessageToUser:(NSString *)msg withTitle:(NSString *)title;
- (void)handleBackground:(BOOL)isBackgroundBright;

@end

typedef NS_ENUM(NSInteger, RRBPalmSDKCaptureMode) {
    RRBPalmSDKCaptureModeEnrollment,
    RRBPalmSDKCaptureModeMatching
};

typedef NS_ENUM(NSInteger, RRBPalmSDKDecoderCameraOrientation) {
    RRBPalmSDKDecoderCameraOrientationHorizontal,
    RRBPalmSDKDecoderCameraOrientationVertical,
    RRBPalmSDKDecoderCameraOrientation360
};


@protocol RRBPalmSDKDecoder <NSObject>

// Decoder internal processing queue
@property (nonatomic, readonly) dispatch_queue_t queue;

@property (nonatomic, readonly) BOOL isDecoderCreated;

- (void)setHandler:(id<RRBPalmSDKDecoderHandler> __nullable)handler;

- (void)setCameraOrientation:(RRBPalmSDKDecoderCameraOrientation)orientation;

- (void)startCaptureWithMode:(RRBPalmSDKCaptureMode)mode andLiveness:(BOOL)enableLiveness;

- (void)startMatchingFor:(RRBPalmSDKModelInfo *)model withModels:(NSArray<RRBPalmSDKModelInfo *> *)models;

/**
 Processes loaded data from camera in library for palm detection.
 This method should be called directly on -[palmDecoder queue]
 
 @param data binary image data, RGB or jpeg binary data
 @param width image width or data length for jpeg
 @param height image height or 1 for jpeg
 @param exifMetadata exif metadata, can contain kRRBPalmSDKExifRearFacingCameraFlag and kRRBPalmSDKExifActiveLightningFlag NSNumber * with bool value to set PalmImage.rear_facing_camera and PalmImage.active_lightning settings
 @param context delegate to call handle* methods on
 */
- (void)processFrameData:(NSData *)data width:(size_t)width height:(size_t)height exifMetadata:(NSDictionary *)exifMetadata context:(__unsafe_unretained id)context;

- (void)addPalmInfoForModel:(RRBPalmSDKModelInfo *)modelInfo;

- (void)removePalmInfoForModel:(RRBPalmSDKModelInfo *)modelInfo;

- (void)removePalmInfoForModelID:(RRBPalmSDKModelID *)modelID;

- (BOOL)getRefocusNeeded;

- (void)setRefocusNeeded:(BOOL) flag;

@end

@interface RRBPalmSDKDecoderSDK : NSObject<RRBPalmSDKDecoder>

- (instancetype)initWithLicenseID:(NSString *)licenseID serverURL:(NSURL * _Nullable)serverURL handler:(id<RRBPalmSDKDecoderHandler>)handler;

@end

NS_ASSUME_NONNULL_END
