//
//  EnrollTutorialViewController.h
//  RRBDemo
//
//  Created by An on 8/26/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^RRBPalmSDKEnrollmentTutorialViewControllerCompletionHandler)(void);

@interface RRBPalmSDKEnrollmentTutorialViewController : UIViewController <UIPageViewControllerDataSource, UIPageViewControllerDelegate>

- (instancetype)init;

@property(nullable, nonatomic, copy) RRBPalmSDKEnrollmentTutorialViewControllerCompletionHandler completionHandler;

@end

NS_ASSUME_NONNULL_END
