//
//  RRBPalmSDKUserPalmModelStorageProtocol.h
//  PalmSDK-iOS
//
//  Created by An on 11/12/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>

//#import "RRBPalmSDKUserProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@class RRBPalmSDKModelInfo;
@protocol RRBPalmSDKUserProtocol;

@protocol RRBPalmSDKUserModelInfoStorageProtocol

- (NSArray<RRBPalmSDKModelInfo *> *)userModels:(id<RRBPalmSDKUserProtocol>)user error:(NSError **)error;

- (BOOL)saveModels:(NSArray<RRBPalmSDKModelInfo *> *)models forUser:(id<RRBPalmSDKUserProtocol>)user error:(NSError **)error;
@end

NS_ASSUME_NONNULL_END
