//
//  RRBPalmSDKCoreFactory.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 5/2/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RRBPalmSDKMain.h"
#import "RRBPalmSDKDecoder.h"

@protocol RRBPalmSDKPersistentDataManager;
@protocol RRBPalmSDKDecoder;

@interface RRBPalmSDKCoreFactory : NSObject

+ (UIViewController *)sdkViewControllerForClass:(Class)controllerClass;
+ (UINavigationController *)navigationControllerWithSDKViewControllerForClass:(Class)controllerClass;

@property (atomic, copy) NSString *licenseID;
@property (atomic, copy) NSURL *serverURL;

// Returns the default singleton instance.
@property (class, readonly, strong) RRBPalmSDKCoreFactory *defaultFactory;

@property (nonatomic, strong, readonly) id<RRBPalmSDKPersistentDataManager> persistentDataManager;

@property (nonatomic) RRBPalmSDKAuthMethod authMethod;

@property (nonatomic) BOOL shouldCachePalmDecoder;

@property (nonatomic, copy) RRBPalmSDKErrorHandler errorHandler;

// pure factory routine
- (id<RRBPalmSDKDecoder>)instantiatePalmDecoderWithHandler:(id<RRBPalmSDKDecoderHandler>)handler;

// manages cached / non caching behavior to make decoder
- (id<RRBPalmSDKDecoder>)makePalmDecoderWithHandler:(id<RRBPalmSDKDecoderHandler>)handler;

- (void)reportError:(NSError *)error;

- (BOOL)isPasscodeSupported;

- (void)setCachedPalmDecoder:(id<RRBPalmSDKDecoder>)palmDecoder;
- (BOOL)hasCachedPalmDecoder;

@end
