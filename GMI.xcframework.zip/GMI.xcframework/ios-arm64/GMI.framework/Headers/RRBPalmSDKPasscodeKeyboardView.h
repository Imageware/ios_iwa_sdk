//
//  PasscodeKeyboardView.h
//  PalmSDK-iOS
//
//  Created by An on 12/3/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//
//  DEPRECATED, not a part of framework anymore

@import UIKit;

#import "RRBPalmSDKXibView.h"

NS_ASSUME_NONNULL_BEGIN


typedef NS_ENUM(NSUInteger, RRBPalmSDKPasscodeKeyboardViewControlKey)
{
    RRBPalmSDKPasscodeKeyboardViewControlKeyDelete,
};

typedef void (^RRBPalmSDKPasscodeKeyboardViewControlKeyHandler)(RRBPalmSDKPasscodeKeyboardViewControlKey controlKey);
typedef void (^RRBPalmSDKPasscodeKeyboardViewKeyHandler)(NSString *key);

IB_DESIGNABLE
@interface RRBPalmSDKPasscodeKeyboardView : RRBPalmSDKXibView

@property (nonatomic, copy) RRBPalmSDKPasscodeKeyboardViewControlKeyHandler controlKeyHandler;
@property (nonatomic, copy) RRBPalmSDKPasscodeKeyboardViewKeyHandler keyHandler;

@end

NS_ASSUME_NONNULL_END
