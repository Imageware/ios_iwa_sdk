//
//  RRBPalmSDKPasscodeView.h
//  PalmSDK-iOS
//
//  Created by An on 12/3/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//
//  DEPRECATED, not a part of framework anymore

@import UIKit;
#import "RRBPalmSDKXibView.h"

NS_ASSUME_NONNULL_BEGIN
/**
 Callback block called when passcode is entered
 @param passcode passcode
 */
typedef void (^RRBPalmSDKPasscodeViewAllEnteredHandler)(NSString *passcode);

/**
 UIView with pins and message
 */
IB_DESIGNABLE
@interface RRBPalmSDKPasscodeView : RRBPalmSDKXibView
/// Passcode length
@property (nonatomic) NSNumber *passcodeLength;
/// Pins and message color
@property (nonatomic) UIColor *tintColor;

/// Callback block called when passcode is entered
@property (nonatomic, copy) RRBPalmSDKPasscodeViewAllEnteredHandler allEnteredHandler;
/// Entered passcode string
@property (nonatomic) NSString *passcode;

/// Delete last characted
- (void)deleteLastCharacter;
/**
 Append string to passcode
 @param string string
 */
- (void)appendInput:(NSString *)string;
/**
 Show message
 @param message message
 @param color color
 */
- (void)showMessage:(NSString *)message withColor:(UIColor *)color;


@end

NS_ASSUME_NONNULL_END
