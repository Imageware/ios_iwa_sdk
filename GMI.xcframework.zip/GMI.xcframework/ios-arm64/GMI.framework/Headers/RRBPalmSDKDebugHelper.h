//
//  RRBPalmSDKDebugSDKTool.h
//  PalmSDK-iOS
//
//  Created by An on 12/6/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

@import UIKit;
@import AVFoundation;

#import "RRBPalmSDKModelInfo.h"
#import "RRBPalmSDKDecoder.h"

NS_ASSUME_NONNULL_BEGIN

@interface RRBPalmSDKDebugHelper : NSObject<RRBPalmSDKDecoderHandler>
/**
 Build model for UIImage
 @param image image
 @param decoder decoder
 @param callback callback called when model is ready
 */
- (void)modelInfoFromImage:(UIImage *)image withDecoder:(id<RRBPalmSDKDecoder>)decoder withCallback:(void(^)(RRBPalmSDKModelInfo * _Nullable modelInfo))callback;

@end

NS_ASSUME_NONNULL_END
