//
//  RRBPalmSDKConnectViewController.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 6/2/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PalmSDKScannerViewContentViewControllerProtocol.h"

@class RRBPalmSDKConnectViewController;

@protocol RRBPalmSDKConnectViewControllerDelegate <NSObject>

// Workflow completed after user cancelled or error. Caller should dismiss UI
- (void)palmConnectViewControllerDidComplete:(RRBPalmSDKConnectViewController *)sender error:(NSError *)error;


@end

@interface RRBPalmSDKConnectViewController : UIViewController <PalmSDKScannerViewContentViewControllerProtocol>

@property (nonatomic, weak) id<RRBPalmSDKConnectViewControllerDelegate> delegate;

@end
