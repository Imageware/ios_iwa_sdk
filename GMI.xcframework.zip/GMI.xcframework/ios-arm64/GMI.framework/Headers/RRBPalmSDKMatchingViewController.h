//
//  RRBPalmSDKMatchingViewController.h
//  PalmSDK-iOS
//
//  Created by An on 12/4/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RRBPalmSDKDecoder.h"
#import "RRBPalmSDKCameraProtocol.h"
#import "RRBPalmSDKCamera.h"

@class RRBPalmSDKModelInfo;

NS_ASSUME_NONNULL_BEGIN

/**
 CompletioncCallback block signature
 
 @param isMatch NO on no match or error
 @param modelMatchResults for match contains modelMatchResults for every model supplied, nil of no match or error, [matchModelIndex unsignedInteger] index of matched model in models array
 @param error error
 */
typedef void (^RRBPalmSDKMatchingViewControllerCompletionHandler)(BOOL isMatch, NSArray<RRBPalmSDKModelMatchResult *> * __nullable modelMatchResults, NSError * __nullable error);

/**
 Matching controller
 
 @discussion
 UI for matching camera stream with the palm models of the user
 */
@interface RRBPalmSDKMatchingViewController : UIViewController

/**
 Create view controller with [RRBPalmSDK decoder].
 
 @param models models to match
 @param cameraPosition camera position
 @param completionHandler completion handler
 @returns instance
 */
- (instancetype)initWithModels:(NSArray<RRBPalmSDKModelInfo *> *)models cameraPosition:(RRBPalmSDKCameraPosition)cameraPosition completionHandler:(RRBPalmSDKMatchingViewControllerCompletionHandler)completionHandler;

/**
 Callback block called on completion
 */
@property (nullable, nonatomic, copy) RRBPalmSDKMatchingViewControllerCompletionHandler completionHandler;
/**
 Decoder. [RRBPalmSDK decoder] by default
 */
@property (nonatomic, weak) id<RRBPalmSDKDecoder> decoder;

/**
 Models to match with. Required
 */
@property (nonatomic) NSArray<RRBPalmSDKModelInfo *> *models;

/**
 Camera. Front camera by default
 */
@property (nonatomic) id<RRBPalmSDKCameraProtocol> camera;
/**
 Liveness setting. NO by default
 */
@property (nonatomic) BOOL livenessEnabled;

@end

NS_ASSUME_NONNULL_END
