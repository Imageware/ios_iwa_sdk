//
//  RRBPalmScannerViewController.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 5/2/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RRBPalmSDKUserInternal;

typedef NS_ENUM(NSInteger, RRBPalmScannerViewControllerWorkflow) {
    RRBPalmScannerViewControllerWorkflowUndefined = 0,
    RRBPalmScannerViewControllerWorkflowModeling,
    RRBPalmScannerViewControllerWorkflowMatching,
};


@class RRBPalmScannerViewController;
@class RRBPalmSDKModelInfo;

@protocol RRBPalmScannerViewControllerDelegate <NSObject>

// Workflow completed after user cancelled or error. Caller should dismiss UI
- (void)palmScannerViewControllerDidComplete:(RRBPalmScannerViewController *)sender error:(NSError *)error;

// Workflow completed after palm data modeled. Caller should dismiss UI
- (void)palmScannerViewController:(RRBPalmScannerViewController *)sender didCompleteModeling:(RRBPalmSDKModelInfo *)modelInfo;

// Workflow completed after palm matched. Caller should dismiss UI
- (void)palmScannerViewController:(RRBPalmScannerViewController *)sender didCompleteMatching:(BOOL)result;

- (UIView *)brandInfoView;

@end

// class that binds communication of RRB palm decoder logic and camera view that provides frames
// Instance of this view controller is a child view controller pf Modeling/Matching view controllers

@interface RRBPalmScannerViewController : UIViewController

@property (nonatomic, weak) id<RRBPalmScannerViewControllerDelegate> delegate;

@property (nonatomic, strong) RRBPalmSDKUserInternal *user;

@property (nonatomic) RRBPalmScannerViewControllerWorkflow workflow;

- (void)showPalmHint:(BOOL)show forLeftPalm:(BOOL)leftPalm;

- (void)disableAuthMethodChange;

- (void)recycle;

@property (nonatomic) BOOL expectRecycling;

@end
