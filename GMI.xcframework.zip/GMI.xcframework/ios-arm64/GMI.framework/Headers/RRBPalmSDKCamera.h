//
//  RRBPalmSDKCamera.h
//  PalmSDK-iOS
//
//  Created by An on 11/25/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//
#import "RRBPalmSDKCameraProtocol.h"

NS_ASSUME_NONNULL_BEGIN

/**
 Supported camera positions
 */
typedef NS_ENUM(NSUInteger, RRBPalmSDKCameraPosition) {
    RRBPalmSDKCameraPositionBack,
    RRBPalmSDKCameraPositionFront
};

/**
 Real iPhone camera protocol implementation.
 
 @discussion
 Camera use authorization will be requested on run if needed.
 */
@interface RRBPalmSDKCamera : NSObject<RRBPalmSDKCameraProtocol>

- (instancetype)init NS_UNAVAILABLE;

/**
 Init camera
 @param cameraPosition camera position
 */
- (instancetype)initWithCameraPosition:(RRBPalmSDKCameraPosition)cameraPosition;

@end

NS_ASSUME_NONNULL_END
