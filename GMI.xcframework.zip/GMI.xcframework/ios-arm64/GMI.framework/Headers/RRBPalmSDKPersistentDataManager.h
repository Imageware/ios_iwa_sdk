//
//  RRBPalmSDKPersistentDataManager.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 5/24/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol RRBPalmSDKPersistentDataManager;

@protocol RRBPalmSDKPersistentDataManagerDelegate <NSObject>

- (void)palmSDKPersistentDataManager:(id<RRBPalmSDKPersistentDataManager>)sender didReceiveError:(NSError *)error;

@end

@protocol RRBPalmSDKPersistentDataManager <NSObject>

@property (nonatomic, weak) id<RRBPalmSDKPersistentDataManagerDelegate> delegate;

- (void)performBlock:(void (^)(void))block;
- (void)performBlockAndWait:(void (^)(void))block;

- (NSString *)domainForUsername:(NSString *)username;

- (void)removeAllData;

- (void)removeDomain:(NSString *)domain;

- (NSData *)readDataForItemID:(NSString *)itemID inDomain:(NSString *)domain;
- (BOOL)dataFileExistsForItemID:(NSString *)itemID inDomain:(NSString *)domain;
- (void)removeDataForItemID:(NSString *)itemID inDomain:(NSString *)domain;
- (void)saveData:(NSData *)data forItemID:(NSString *)itemID inDomain:(NSString *)domain;

- (void)assertIfWrongQueue;

@end


@interface RRBPalmSDKPersistentDataManagerImpl : NSObject <RRBPalmSDKPersistentDataManager>

@end
