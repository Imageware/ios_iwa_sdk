//
//  RRBPalmSDKMain+Private.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 6/23/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "RRBPalmSDKMain.h"
#import "RRBPalmSDKDecoder.h"


@interface RRBPalmSDK  (Private)

+ (BOOL)hasPalmDecoder;
+ (id<RRBPalmSDKDecoder>)instantiatePalmDecoderWithHandler:(id<RRBPalmSDKDecoderHandler>)handler;
+ (void)setPalmDecoder:(id<RRBPalmSDKDecoder>)decoder;
+ (void)optimizeForSubsequentUsage;

@end

