//
//  RRBPalmSDKModelScanner.h
//  PalmSDK-iOS
//
//  Created by An on 12/17/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>


#import "RRBPalmSDKWorkflow.h"

@class RRBPalmSDKCameraViewfinderView;
@class RRBPalmSDKModelInfo;
@protocol RRBPalmSDKCameraProtocol;
@protocol RRBPalmSDKDecoder;

NS_ASSUME_NONNULL_BEGIN

/**
 Model scanner delegate
 */
@protocol RRBPalmSDKModelScannerDelegate <NSObject>
/**
 Notifies the delegate the error occured
 @param error error
 */
- (void)handleError:(NSError *)error;
/**
 Notifies the delegate that model is ready
 @param modelInfo model
 */
- (void)handleModelInfo:(RRBPalmSDKModelInfo *)modelInfo;

@optional
/**
 Notifies the delegate the camera is ready
 */
- (void)handleCameraReady;
@end

/**
 Model scanner.
 
 @discussion Model scanner perform setup and interaction between viewfinder UI, camera and decoder when creating palm model.
 */
@interface RRBPalmSDKModelScanner : NSObject
/**
 Delegate
 */
@property (weak, nonatomic) id<RRBPalmSDKModelScannerDelegate> delegate;
/**
 Viewfinder
 */
@property (weak, nonatomic) RRBPalmSDKCameraViewfinderView *viewfinder;
/**
 Camera. Front camera by default
 */
@property (nonatomic) id<RRBPalmSDKCameraProtocol> camera;
/**
Decoder. [RRBPalmSDK decoder] by default
*/
@property (nonatomic) id<RRBPalmSDKDecoder> decoder;

/**
 Start modeling for workflow
 @param workflow workflow
 */
- (void)captureModelWithWorkflow:(RRBPalmSDKWorkflow)workflow  livenessEnabled:(BOOL)livenessEnabled;
/**
 Stop modeling
 */
- (void)stop;

@end

NS_ASSUME_NONNULL_END
