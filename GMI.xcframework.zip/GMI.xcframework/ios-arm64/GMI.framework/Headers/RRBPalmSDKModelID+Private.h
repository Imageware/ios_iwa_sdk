//
//  RRBPalmSDKModelID+Private.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 6/26/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <PalmAPI/PalmID.h>

#import "RRBPalmSDKModelID.h"


@interface RRBPalmSDKModelID (Private)

- (instancetype)initWithModelID:(const PalmModelID *)modelID;

@property (nonatomic, assign, readonly) const PalmModelID *modelID;

@end
