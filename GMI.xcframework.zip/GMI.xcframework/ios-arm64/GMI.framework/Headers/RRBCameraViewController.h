//
//  RRBCameraViewController.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 4/25/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PalmSDKScannerViewContentViewControllerProtocol.h"

@class RRBCameraViewController;

@protocol RRBCameraViewControllerDelegate <NSObject>

- (void)cameraViewControllerDidComplete:(RRBCameraViewController *)sender error:(NSError *)error;

- (dispatch_queue_t)decoderQueue;

- (NSData *)loadFrameFromBufer:(uint8_t *)baseAddress width:(size_t)width height:(size_t)height;

- (void)processFrameData:(NSData *)data width:(size_t)width height:(size_t)height;

@end


@protocol RRBOverlayController <NSObject>

- (void)showPalmAtPoints:(CGPoint)a b:(CGPoint)b  c:(CGPoint)c  d:(CGPoint)d;
- (void)hideTrackedPalm;
- (void)showHint:(BOOL)show forLeftPalm:(BOOL)leftPalm;
- (void)showMatchingResult:(BOOL)matched;
- (void)showLivenessInfo;
- (void)showInfoText:(NSString *)infoText;
- (void)showBrandInfoView:(UIView *)brandView;
@end

@interface RRBCameraViewController : UIViewController <PalmSDKScannerViewContentViewControllerProtocol>
@property (nonatomic, weak) id<RRBCameraViewControllerDelegate> delegate;
@property (nonatomic, strong, readonly) id<RRBOverlayController> overlayController;
@property (nonatomic, readonly) BOOL isViewReady;
@property (nonatomic) BOOL dismissOnAppear;

@end
