//
//  RRBPalmSDKOverlayControlsView.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 6/9/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RRBPalmSDKOverlayControlsView : UIView

@end
