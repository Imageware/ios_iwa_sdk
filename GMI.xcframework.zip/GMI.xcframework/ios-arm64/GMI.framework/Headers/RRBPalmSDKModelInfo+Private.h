//
//  RRBPalmSDKModelInfo+Private.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 6/27/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import "RRBPalmSDKModelInfo.h"

@class RRBPalmSDKModelID;

@interface RRBPalmSDKModelInfo (Private)

- (instancetype)initWithModelID:(RRBPalmSDKModelID *)modelID data:(NSData *)modelData;

@property (nonatomic, assign) BOOL isPersistent;

@end
