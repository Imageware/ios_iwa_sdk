//
//  RRBCameraPreviewView.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 4/25/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

@import UIKit;
@import AVFoundation;

@interface RRBCameraPreviewView : UIView

@property (nonatomic, readonly) AVCaptureVideoPreviewLayer *videoPreviewLayer;
@property (nonatomic) AVCaptureSession *session;

@end

