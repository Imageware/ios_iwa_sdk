//
//  RRBPalmSDKUserProtocol.h
//  PalmSDK-iOS
//
//  Created by An on 11/11/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

typedef NS_ENUM(NSInteger, RRBPalmSDKUserPalmType) {
    RRBPalmSDKUserPalmTypeLeft = 0,
    RRBPalmSDKUserPalmTypeRight = 1,
};

#include "RRBPalmSDKModelInfo.h"

NS_ASSUME_NONNULL_BEGIN

@protocol RRBPalmSDKUserProtocol <NSObject, NSCoding>

@property (nonatomic, readonly) NSString *uniqueID;

@property (nonatomic) NSString *username;

@property (nonatomic) NSArray<RRBPalmSDKModelInfo *> *models;

@end

NS_ASSUME_NONNULL_END
