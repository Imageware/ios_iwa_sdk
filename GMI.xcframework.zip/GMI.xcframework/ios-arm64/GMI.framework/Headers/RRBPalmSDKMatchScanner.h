//
//  RRBPalmSDKModelScanner.h
//  PalmSDK-iOS
//
//  Created by An on 12/17/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>

@class RRBPalmSDKCameraViewfinderView;
@class RRBPalmSDKModelInfo;
@class RRBPalmSDKModelMatchResult;

@protocol RRBPalmSDKCameraProtocol;
@protocol RRBPalmSDKDecoder;

NS_ASSUME_NONNULL_BEGIN

/**
 Match scanner delegate
 */
@protocol RRBPalmSDKMatchScannerDelegate <NSObject>
/**
 Notifies the delegate the error occured
 @param error error
 */
- (void)handleError:(NSError *)error;

/**
 Notifies the delegate that matching is done
 @param isMatch is there match for supplied models
 @param results model results for each model from the -[RRBPalmSDKMatchScanner matchModels:livenessEnabled:] on match, or nil if there is no match
 */
- (void)handleMatchResult:(BOOL)isMatch modelMatchResults:(nullable NSArray<RRBPalmSDKModelMatchResult *> *)results;

/**
 Pass a message to the user
*/
- (void)passMessageToUser:(NSString *)msg withTitle:(NSString *)title;

@optional
/**
 Notifies the delegate the camera is ready
 */
- (void)handleCameraReady;
@end

/**
 Match scanner.
 
 @discussion Match scanner perform setup and interaction between viewfinder UI, camera and decoder for matching with the supplied models
 */
@interface RRBPalmSDKMatchScanner : NSObject

/**
 Delegate
 */
@property (weak, nonatomic) id<RRBPalmSDKMatchScannerDelegate> delegate;
/**
 Viewfinder
 */
@property (weak, nonatomic) RRBPalmSDKCameraViewfinderView *viewfinder;
/**
 Camera. Front camera by default
 */
@property (nonatomic) id<RRBPalmSDKCameraProtocol> camera;
/**
 Decoder. [RRBPalmSDK decoder] by default
 */
@property (nonatomic) id<RRBPalmSDKDecoder> decoder;

/**
 Start matching
 @param models models to match with
 @param livenessEnabled enable or disable liveness check
 */
- (void)matchModels:(NSArray<RRBPalmSDKModelInfo *> *)models livenessEnabled:(BOOL)livenessEnabled;
/**
 Stop matching
 */
- (void)stop;

@end

NS_ASSUME_NONNULL_END
