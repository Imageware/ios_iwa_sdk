//
//  RRBPalmSDKModelMatchResult.h
//  RRBPalmSDK2
//
//  Created by An on 1/13/20.
//  Copyright © 2020 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RRBPalmSDKModelInfo.h"

NS_ASSUME_NONNULL_BEGIN

/**
Matching result holder
*/
@interface RRBPalmSDKModelMatchResult : NSObject
/**
 Is corresponding model matched or not
 */
@property (nonatomic) BOOL isMatch;
/**
 Matchin score
 */
@property (nonatomic) float score;
/**
 Is model is updated
 */
@property (nonatomic) BOOL updated;
/**
 Updated model data
 */
@property (nullable, nonatomic) RRBPalmSDKModelInfo *updatedModel;

@end

NS_ASSUME_NONNULL_END
