//
//  RRBCameraOverlayView.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 4/30/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "RRBCameraViewController.h"

@interface RRBCameraOverlayView : UIView

@property (nonatomic) CGFloat topDistanceToViewArea;
@property (nonatomic) CGFloat bottomDistanceToViewArea;

- (void)showPalmAtPoints:(CGPoint)a b:(CGPoint)b  c:(CGPoint)c  d:(CGPoint)d;
- (void)hideTrackedPalm;
- (void)showMatchingResult:(BOOL)matched;
- (void)showLivenessInfo;
- (void)setBorderColor:(UIColor *)color;
- (void)setViewColor:(UIColor *)color;

@end
