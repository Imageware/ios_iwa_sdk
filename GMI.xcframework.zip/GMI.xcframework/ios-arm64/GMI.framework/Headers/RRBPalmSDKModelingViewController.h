//
//  RRBPalmSDKModelingViewController.h
//  PalmSDK-iOS
//
//  Created by An on 11/29/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

@import UIKit;

#import "RRBPalmSDKWorkflow.h"

@class RRBPalmSDKModelInfo;
@protocol RRBPalmSDKDecoder;

@protocol RRBPalmSDKCameraProtocol;

NS_ASSUME_NONNULL_BEGIN

/**
 Completion handler block signature
 @param modelInfo model info, check error if nil
 @param error error
 */
typedef void (^RRBPalmSDKModelingViewControllerCompletionHandler)(RRBPalmSDKModelInfo * __nullable modelInfo, NSError * __nullable error);

/**
 Create model info handler block signature
 @param modelInfo model info
 */
typedef void (^RRBPalmSDKModelingViewControllerModelInfoCreatedHandler)(RRBPalmSDKModelInfo * __nonnull modelInfo);

/**
 Modeling view controller.
 
 @discussion
 Modeling controller shows UI for building user palm model. Palm model can be build for matching or enrollment.
 */
@interface RRBPalmSDKModelingViewController : UIViewController

/**
 Callback block called on completion
 */
@property(nullable, nonatomic, copy) RRBPalmSDKModelingViewControllerCompletionHandler completionHandler;

/**
 Callback block called right after model creation
 */
@property(nullable, nonatomic, copy) RRBPalmSDKModelingViewControllerModelInfoCreatedHandler modelInfoCreatedHandler;

/**
 Decoder. [RRBPalmSDK decoder] by default
 */
@property (nonatomic, weak) id<RRBPalmSDKDecoder> decoder;

/**
 Camera. Connect front camera by default
 */
@property (nonatomic) id<RRBPalmSDKCameraProtocol> camera;

/**
 Palm model modeling mode. RRBPalmSDKWorkflowModeling by default
 */
@property (nonatomic) RRBPalmSDKWorkflow workflow;

/**
 Text shown above the viewfinder.
 */
@property (nonatomic) NSString *hintText;

/**
 Liveness setting. NO by default
 */
@property (nonatomic) BOOL livenessEnabled;

@end

NS_ASSUME_NONNULL_END
