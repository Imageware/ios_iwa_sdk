//
//  RRBPalmSDKPasscodeViewController.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 6/5/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PalmSDKScannerViewContentViewControllerProtocol.h"

@class RRBPalmSDKPasscodeViewController;

@protocol RRBPalmSDKPasscodeViewControllerDelegate <NSObject>

- (BOOL)palmSDKPasscodeViewController:(RRBPalmSDKPasscodeViewController *)sender userDidEnterPasscode:(NSString *)passcode;

- (void)palmSDKPasscodeViewControllerAuthSuccessReported:(RRBPalmSDKPasscodeViewController *)sender;

- (void)palmSDKPasscodeViewControllerUserDidRequestCancel:(RRBPalmSDKPasscodeViewController *)sender;

@end

@interface RRBPalmSDKPasscodeViewController : UIViewController<PalmSDKScannerViewContentViewControllerProtocol>

@property (nonatomic, weak) id<RRBPalmSDKPasscodeViewControllerDelegate> delegate;

@end
