//
//  RRBPalmSDKPasscodeViewController.h
//  PalmSDK-iOS
//
//  Created by An on 12/3/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//
//  DEPRECATED, not a part of framework anymore

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Callback signature to handle passcode view controller completion
 @param passcode passcode or nil on error
 @param error error
 */
typedef void (^RRBPalmSDKPasscodeViewControllerCompletionHandler)(NSString * __nullable passcode, NSError * __nullable error);

/**
 View to enter 4-digit passcode
 */
@interface RRBPalmSDKPasscodeViewController : UIViewController

/// Callback block called when user is finished with the UI
@property (nullable, nonatomic, copy) RRBPalmSDKPasscodeViewControllerCompletionHandler completionHandler;

/**
 Show message under the passcode dots
 @param message message
 @param color message text color
 */
- (void)showMessage:(NSString *)message withColor:(UIColor *)color;

/**
 Clear user input and reset the message
 */
- (void)reset;
@end

NS_ASSUME_NONNULL_END
