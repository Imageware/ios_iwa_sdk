//
//  RRBPalmMatchingViewController.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 5/2/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RRBPalmSDKAuthViewController.h"

// public methods of RRBPalmSDKAuthViewController should be in this protocol
@protocol RRBPalmSDKAuthViewControllerProtocol <NSObject>

@property(nullable, nonatomic, copy) RRBPalmSDKAuthViewControllerCompletionHandler completionHandler;

@property (nonatomic, strong) UIView * _Nullable brandInfoView;

@end

@class RRBPalmSDKUserInternal;

@interface RRBPalmMatchingViewController : UIViewController <RRBPalmSDKAuthViewControllerProtocol>

@property (nonatomic, strong) RRBPalmSDKUserInternal * _Nonnull user;

@end
