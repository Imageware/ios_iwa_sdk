//
//  RRBPalmSDK.h
//  PalmSDK-iOS
//
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

#if TARGET_IPHONE_SIMULATOR

#else

/**
 Low level SDK
 */
#import "RRBPalmSDKDecoder.h"

/**
 Matching result
 */
#import "RRBPalmSDKModelMatchResult.h"

/**
 Palm model data wrapper
 */
#import "RRBPalmSDKModelInfo.h"

/**
 Errors
 */
#import "RRBPalmSDKError.h"

/**
 RRBPalmSDK helper for shared low-level SDK instance creation and storage
 */
#import "RRBPalmSDKMain.h"

/**
 User protocol
 */
#import "RRBPalmSDKUserProtocol.h"
/**
 User implementation with models lazy loading from the storage
 */
#import "RRBPalmSDKUser.h"

/**
 User storage protocol
 */
#import "RRBPalmSDKUserStorageProtocol.h"
//#import "RRBPalmSDKUserModelInfoStorageProtocol.h"
/**
 User storage implementation
 */
#import "RRBPalmSDKFilesystemUserStorage.h"

/**
 Custom UIView that can show camera preview, distance meter and messages
 */
#import "RRBPalmSDKCameraViewfinderView.h"
/**
 Camera protocol
 */
#import "RRBPalmSDKCameraProtocol.h"
/**
 Device camera implementation. Handles authorization requests if neccessary.
 */
#import "RRBPalmSDKCamera.h"

/**
 Workflow enum for Modeling
 */
#import "RRBPalmSDKWorkflow.h"

/**
 Scanner object helper to perform modeling. Glue between viewfinder (UI), decoder (low-level SDK) and camera.
 */
#import "RRBPalmSDKModelScanner.h"
/**
 View controller that creates one palm model.
 */
#import "RRBPalmSDKModelingViewController.h"
/**
 View controller to create 2 palm models. If same palm is showed twice it will show message. Returns 2 palm models, they can be with the same sidedness.
 */
#import "RRBPalmSDKEnrollPalmsViewController.h"
 
/**
Scanner object helper to perform matching. Glue between viewfinder (UI), decoder (low-level SDK) and camera.
*/
#import "RRBPalmSDKMatchScanner.h"
/**
 View controller for matching array of models with the camera stream. If there is a match it will return updated model as well.
 */
#import "RRBPalmSDKMatchingViewController.h"

/**
 View controller to show instructions about the palm placement for the best modeling and matching.
 */
#import "RRBPalmSDKEnrollmentTutorialViewController.h"

/**
 RRBPalmSDK colors
 */
#import "UIColor+RRBPalmSDKColors.h"
/**
 RRBPalmSDK navigation bar buttons
 */
#import "UIBarButtonItem+RRBPalmSDKNavigation.h"

/**
 Network reachability manager. Provides interface to handle network status changes.
*/
#import "RRBPalmSDKReachabilityManager.h"

/**
 Camera implementation for using static images as camera stream.
 */
#import "RRBPalmSDKMockCamera.h"
/**
 Debug helper methods for tests.
 */
#import "RRBPalmSDKDebugHelper.h"

/**
 Image helper
 */
#import "RRBPalmSDKImageHelper.h"

#endif
