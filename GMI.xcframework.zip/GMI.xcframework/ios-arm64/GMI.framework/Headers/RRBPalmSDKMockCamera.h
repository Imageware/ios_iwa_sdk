//
//  RRBPalmSDKCameraMock.h
//  PalmSDK-iOS
//
//  Created by An on 12/5/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

@import Foundation;

#import "RRBPalmSDKCameraProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface RRBPalmSDKMockCamera : NSObject<RRBPalmSDKCameraProtocol>
/**
 Init camera mock with images
 @param images NSArray of images. Each camera run will show next image from the list. After last images first image will be shown
 */
- (instancetype)initWithImages:(NSArray *)images;

@end

NS_ASSUME_NONNULL_END
