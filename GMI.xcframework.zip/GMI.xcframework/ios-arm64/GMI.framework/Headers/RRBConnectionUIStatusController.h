//
//  RRBConnectionUIStatusController.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 5/17/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RRBConnectionUIStatusController : NSObject

- (instancetype)initWithLabel:(UILabel *)label;

- (void)start;
- (void)stop;

@end
