//
//  RRBCameraPreviewView.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 4/25/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

@import UIKit;
@import AVFoundation;

/**
 View with the AVCaptureVideoPreviewLayer layer
 */
@interface RRBPalmSDKCameraPreviewView : UIView
/// Video preview layer
@property (nonatomic, readonly) AVCaptureVideoPreviewLayer *videoPreviewLayer;
/// Capture session for the preview layter
@property (nonatomic) AVCaptureSession *session;

@end

