//
//  RRBPalmSDKReachabilityManager.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 5/17/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef enum : NSInteger {
	NotReachable = 0,
	ReachableViaWiFi,
	ReachableViaWWAN
} NetworkStatus;


typedef void (^RRBPalmSDKReachabilityHandler)(void);

@interface RRBPalmSDKReachabilityManager : NSObject

@property(nullable, nonatomic, copy) RRBPalmSDKReachabilityHandler reachabilityHandler;

- (BOOL)start;
- (void)stop;

- (NetworkStatus)currentReachabilityStatus;

- (BOOL)isVPNConnected;

@end
