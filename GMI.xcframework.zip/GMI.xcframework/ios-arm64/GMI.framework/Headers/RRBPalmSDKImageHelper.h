//
//  RRBPalmSDKImageHelper.h
//  PalmSDK-iOS
//
//  Created by An on 12/6/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RRBPalmSDKImageData : NSObject
@property (nonatomic) size_t width;
@property (nonatomic) size_t height;
@property (nonatomic) NSData *pixelData;
@end

@interface RRBPalmSDKImageHelper : NSObject

+ (RRBPalmSDKImageData *)imageDataForImage:(UIImage *)image;
+ (NSData *)convertBGRA2BGR:(const uint8_t *)baseAddress width:(size_t)width height:(size_t)height andHorizontalFlip:(BOOL)flip;

@end

NS_ASSUME_NONNULL_END
