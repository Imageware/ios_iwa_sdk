//
//  RRBPalmSDKPasscodeConfigViewController.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 6/7/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>



typedef NS_ENUM(NSInteger, RRBPalmSDKPasscodeConfigViewControllerUserAction) {
    RRBPalmSDKPasscodeConfigViewControllerUserActionCancel,
    RRBPalmSDKPasscodeConfigViewControllerUserActionSave,
    RRBPalmSDKPasscodeConfigViewControllerUserActionRemove,
};

typedef void (^RRBPalmSDKPasscodeConfigViewControllerCompletion)(RRBPalmSDKPasscodeConfigViewControllerUserAction action, NSString * __nullable passcode);



@interface RRBPalmSDKPasscodeConfigViewController : UITableViewController

@property (nonatomic, strong)  NSString * __nullable passcodeString;

@property (nonatomic, copy) RRBPalmSDKPasscodeConfigViewControllerCompletion __nonnull completionHandler;

@property (nonatomic, strong)  UINavigationItem * __nullable parentNavigationItem;

@end
