//
//  UIView+Container.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 6/29/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIView (RRBViewContainer)

- (void)rrbPalmSDK_addSubviewFittingBounds:(UIView *)subview;

@end
