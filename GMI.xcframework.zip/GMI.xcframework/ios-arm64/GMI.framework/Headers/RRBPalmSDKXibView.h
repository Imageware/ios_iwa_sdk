//
//  RRBPalmSDKXibView.h
//  PalmSDK-iOS
//
//  Created by An on 12/3/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Xib view loader helper
 */
@interface RRBPalmSDKXibView : UIView

- (instancetype)initWithFrame:(CGRect)frame;

- (instancetype)initWithCoder:(NSCoder *)coder;

- (void)setupView;

- (void)prepareForInterfaceBuilder;
@end

NS_ASSUME_NONNULL_END
