//
//  UserLocalStorage.h
//  RRBDemo
//
//  Created by An on 11/8/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "RRBPalmSDKUserStorageProtocol.h"
#import "RRBPalmSDKUserModelInfoStorageProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface RRBPalmSDKFilesystemUserStorage : NSObject<RRBPalmSDKUserStorageProtocol, RRBPalmSDKUserModelInfoStorageProtocol>

- (instancetype)init;
- (instancetype)initWithFolder:(NSString *)folder;
- (BOOL)removeAllDataWithError:(NSError **)error;
@end

NS_ASSUME_NONNULL_END
