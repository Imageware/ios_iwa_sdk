//
//  UIViewController+Container.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 6/3/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (RRBViewControllerContainer)

- (void)rrbPalmSDK_addViewController:(UIViewController *)childViewController toContainerView:(UIView *)containerView;
- (void)rrbPalmSDK_addViewController:(UIViewController *)childViewController toContainerView:(UIView *)containerView animated:(BOOL)animated;
- (void)rrbPalmSDK_addViewController:(UIViewController *)childViewController toContainerView:(UIView *)containerView animated:(BOOL)animated completion:(dispatch_block_t)completion;

- (void)rrbPalmSDK_removeFromContainerView;
- (void)rrbPalmSDK_removeFromContainerViewAnimated:(BOOL)animated;


- (void)rrbPalmSDK_transitionFromViewController:(UIViewController *)fromController
               toViewController:(UIViewController *) toController
                  withAnimation:(UIViewAnimationOptions) direction
                  completion:(dispatch_block_t)completion;

- (void)rrbPalmSDK_transitionFromViewController:(UIViewController *)fromController
               toViewController:(UIViewController *)toController
                  withAnimation:(UIViewAnimationOptions)direction
                  animations:(dispatch_block_t)animations
                  completion:(dispatch_block_t)completion;

@end

