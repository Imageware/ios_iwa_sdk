//
//  RRBPalmSDKCamera.h
//  PalmSDK-iOS
//
//  Created by An on 11/25/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//
@import UIKit;

/**
 Supported torch modes
 */
typedef NS_ENUM(NSUInteger, RRBPalmSDKTorchMode) {
    /// Torch off
    RRBPalmSDKTorchModeOff,
    /// Torch on
    RRBPalmSDKTorchModeOn,
};

NS_ASSUME_NONNULL_BEGIN

/**
 Camera delegate
 */
@protocol RRBPalmSDKCameraDelegate <NSObject>

/**
 Decoder queue.
 
 @discussion This queue is used for handling capture frames and will skip frames if decoder queue is busy at the moment.
 @returns dispatch queue
 */
- (dispatch_queue_t)decoderQueue;

/**
 Notifies the delegate that camera frame is ready
 @param data 24-bits RGB pixel data
 @param width frame width
 @param height frame height
 @param exifMetadata exit metadata dictionary
 */
- (void)handleCameraFrameData:(NSData *)data width:(size_t)width height:(size_t)height exifMetadata:(NSDictionary *)exifMetadata;

/**
 Notifies the delegate that there is an error occured
 @param error error
 */
- (void)handleCameraError:(NSError *)error;

/**
 Notifies the delegate that camera is ready.
 */
- (void)handleCameraReady;
@end

/**
 Camera protocol
 */
@protocol RRBPalmSDKCameraProtocol <NSObject>

/**
 Delegate
 */
@property (nonatomic, weak) id<RRBPalmSDKCameraDelegate> delegate;

/**
 Preview view
 */
@property (nonatomic, weak) UIView *previewView;

/**
 Run camera
 @param torchMode should torch will be on or off for this run
 */
 - (void)runWithTorchMode:(RRBPalmSDKTorchMode)torchMode;

/**
 Stop camera
 */
- (void)stop;

/**
 Capture photo while running video stream
 */
- (void)capturePhoto; // called by RRBScannerViewController for liveness-flash

/**
 Check if torch is available
 @returns torch is available
 */
- (BOOL)hasTorch;

/**
 Check whether device is currently adjusting focus
 */
- (BOOL)isAdjustingFocus;

/**
 Force re-triggering of auto-focus (temporarily change to "locked", then back to continuousAutoFocus)
 */
- (void)startTriggerRefocus;
- (void)finishTriggerRefocus;

- (void)toggleExposureBias:(BOOL)enable;

- (CGSize)getResolution;
@end

NS_ASSUME_NONNULL_END
