//
//  RRBPalmSDKAccountsViewController-Private.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 5/29/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import "RRBPalmSDKAccountsViewController.h"

@protocol RRBPalmSDKAccountsViewControllerProtocol <NSObject>

@property (nonatomic, copy) RRBPalmSDKAccountsViewControllerUserLoginAttemptHandler userLoginAttemptHandler;

@property (nonatomic, copy) RRBPalmSDKAccountsViewControllerNewUserHandler newUserHandler;

@end
