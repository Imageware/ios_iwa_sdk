//
//  RRBPalmSDKCameraViewfinderView.h
//  PalmSDK-iOS
//
//  Created by An on 11/15/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

@import UIKit;
@import AVFoundation;

#import "RRBPalmSDKWorkflow.h"
#import "RRBPalmSDKXibView.h"

NS_ASSUME_NONNULL_BEGIN

/**
 Camera viewfinder UI
 
 @discussion
 Camera viewfinder provides UI that shows camera preview view, distance meter and messages over camera preview.
 
 Palm position requirements differs for the matching and enrollment workflow. User workflow property to set appropriate workflow.
 */
IB_DESIGNABLE
@interface RRBPalmSDKCameraViewfinderView : RRBPalmSDKXibView
/// Preview view
@property (weak, nonatomic) IBOutlet UIView *previewView;
/// Workflow
@property (nonatomic) RRBPalmSDKWorkflow workflow;

/**
 Shows palm indicator for the provided quadrangle coordinates
 @param a vertex coordinate
 @param b vertex coordinate
 @param c vertex coordinate
 @param d vertex coordinate
 @param longRange long range palm detection enabled
 */
- (void)showPalmAtPoints:(CGPoint)a b:(CGPoint)b  c:(CGPoint)c  d:(CGPoint)d longRange:(BOOL)longRange;
/**
 Hide palm indicator
 */
- (void)hidePalm;

/**
 Show message
 @param text text
 @param color background color
 */
- (void)showMessage:(NSString *)text onBackgroundColor:(UIColor *)color;

/**
 Hide message
*/
- (void)hideMessage;

- (void)setLivenessEnabled:(BOOL) livenessEnabled;

@end

NS_ASSUME_NONNULL_END
