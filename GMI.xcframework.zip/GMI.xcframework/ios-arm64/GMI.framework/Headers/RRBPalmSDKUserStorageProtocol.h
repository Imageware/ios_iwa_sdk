//
//  UserStorageProtocol.h
//  RRBDemo
//
//  Created by An on 11/8/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "RRBPalmSDKUserProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@protocol RRBPalmSDKUserStorageProtocol
- (NSArray<id<RRBPalmSDKUserProtocol>> *)usersWithError:(NSError **)error;
- (BOOL)saveUser:(id<RRBPalmSDKUserProtocol>)user error:(NSError **)error;
- (BOOL)removeUser:(id<RRBPalmSDKUserProtocol>)user error:(NSError **)error;
@end

NS_ASSUME_NONNULL_END
