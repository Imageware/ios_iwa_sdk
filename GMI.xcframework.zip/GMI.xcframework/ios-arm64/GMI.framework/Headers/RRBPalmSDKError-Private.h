//
//  RRBPalmSDKError-Private.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 5/4/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import "RRBPalmSDKError.h"


@interface RRBPalmErrorHelper : NSObject
+ (NSError *)errorWithCode:(NSInteger)code;
+ (NSError *)errorWithCode:(NSInteger)code info:(NSDictionary *)info;
+ (NSError *)errorWithCode:(NSInteger)code originalError:(NSError *)originalError;
+ (NSError *)errorWithPalmAPICode:(NSInteger)code info:(NSDictionary *)info;

+ (BOOL)isError:(NSError *)error palmSDKErrorWithCode:(NSUInteger)code;

@end


#define RRBPalmErrorUnknown [RRBPalmErrorHelper errorWithCode:RRBPalmSDKErrorUnknown info: @{@"file": [NSString stringWithFormat:@"%@:%@", [[NSString stringWithUTF8String:__FILE__] lastPathComponent], @(__LINE__)]}]


#define RRBPalmSDKDecoderSDKError(sdkErrorCode, apiName) [RRBPalmErrorHelper errorWithPalmAPICode:sdkErrorCode info: @{@"file": [NSString stringWithFormat:@"%@:%@", [[NSString stringWithUTF8String:__FILE__] lastPathComponent], @(__LINE__)], @"code": @(sdkErrorCode), @"func": apiName}]


#define RRBPalmCryptoError(code, cryptoErrorCode, apiName) [RRBPalmErrorHelper errorWithCode:code info: @{@"file": [NSString stringWithFormat:@"%@:%@", [[NSString stringWithUTF8String:__FILE__] lastPathComponent], @(__LINE__)], @"code": @(cryptoErrorCode), @"func": apiName}]


#define RRBLOCSTR(s) NSLocalizedStringFromTableInBundle(s, nil, [NSBundle bundleForClass:[self class]], @"")
