//
//  RRBPalmSDKCryptography.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 5/23/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RRBPalmSDKCryptography : NSObject

- (NSData *)encryptData:(NSData *)data error:(NSError **)error;

- (NSData *)decryptData:(NSData *)data error:(NSError **)error;

// private by nature - should be used only in private imp or for tests
- (void)deleteSymmetricKey;

@end
