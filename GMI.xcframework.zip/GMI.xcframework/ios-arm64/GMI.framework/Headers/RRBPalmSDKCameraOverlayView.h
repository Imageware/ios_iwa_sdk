//
//  RRBCameraOverlayView.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 4/30/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

@import UIKit;
#import "RRBPalmSDKWorkflow.h"

@interface RRBPalmSDKCameraOverlayView : UIView

@property (nonatomic) RRBPalmSDKWorkflow workflow;

@property (nonatomic) BOOL livenessEnabled;

/**
 Shows palm indicator for the provided quadrangle coordinates
 @param a vertex coordinate
 @param b vertex coordinate
 @param c vertex coordinate
 @param d vertex coordinate
 @param longRange long range palm detection enabled
 */
- (void)showPalmAtPoints:(CGPoint)a b:(CGPoint)b  c:(CGPoint)c  d:(CGPoint)d longRange:(BOOL)longRange;
/**
 Hide palm indicator
 */
- (void)hideTrackedPalm;
/**
 Show message
 @param text text
 @param color background color
 */
- (void)showResultMessage:(NSString *)text color:(UIColor *)color;
/**
 Hide message
 */
- (void)hideMessage;

@end
