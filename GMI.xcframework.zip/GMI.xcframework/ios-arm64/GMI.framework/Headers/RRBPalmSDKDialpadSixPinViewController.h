//
//  RRBPalmSDKDialpadSixPinViewController.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 6/2/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^RRBPalmSDKDialpadPinViewControllerAllPinsEnteredHandler)(NSString *pins);

@interface RRBPalmSDKDialpadPinViewController : UIViewController

- (void)handleInput:(NSString *)inputString;

- (void)showPinsMatched:(BOOL)matched;
- (void)reset;

- (void)deleteLastKey;

@property (nonatomic, copy) RRBPalmSDKDialpadPinViewControllerAllPinsEnteredHandler allPinsEnteredHandler;

@property (strong, nonatomic, readonly) UIColor *matchedColor;
@property (strong, nonatomic, readonly) UIColor *nonMatchedColor;

@end



@interface RRBPalmSDKDialpadSixPinViewController : RRBPalmSDKDialpadPinViewController
@end

@interface RRBPalmSDKDialpadFourPinViewController : RRBPalmSDKDialpadPinViewController
@end
