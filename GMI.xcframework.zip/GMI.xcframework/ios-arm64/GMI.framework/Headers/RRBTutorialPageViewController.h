//
//  TutorialPageViewController.h
//  RRBDemo
//
//  Created by An on 8/26/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RRBTutorialPageViewController : UIViewController

@property NSString *text;
@property NSString *imageName;
@property int index;

@end

NS_ASSUME_NONNULL_END
