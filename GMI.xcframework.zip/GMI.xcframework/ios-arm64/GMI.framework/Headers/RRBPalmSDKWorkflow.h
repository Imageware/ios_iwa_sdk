//
//  RRBPalmSDKWorkflow.h
//  PalmSDK-iOS
//
//  Created by An on 12/11/19.
//  Copyright © 2019 RedRock Biometrics. All rights reserved.
//
/**
 Workflow constant
 */
typedef NS_ENUM(NSInteger, RRBPalmSDKWorkflow) {
    /// Modeling
    RRBPalmSDKWorkflowModeling,
    /// Matching
    RRBPalmSDKWorkflowMatching,
};
