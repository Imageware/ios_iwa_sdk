//
//  RRBPalmSDKSettingsUserDataProvider.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 5/18/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, RRBPalmSDKSettingsUserDataProviderFeatures) {
    RRBPalmSDKSettingsUserDataProviderFeaturesPalms = 0,
    RRBPalmSDKSettingsUserDataProviderFeaturesLiveness,
    RRBPalmSDKSettingsUserDataProviderFeaturesPasscode,
    RRBPalmSDKSettingsUserDataProviderFeaturesReEnroll,
    RRBPalmSDKSettingsUserDataProviderFeaturesRemoveAccount,
};

@class RRBPalmSDKUserInternal;

@interface RRBPalmSDKSettingsUserDataProvider : NSObject

- (instancetype)initWithUser:(RRBPalmSDKUserInternal *)user;

- (NSArray<NSNumber *> *)features;

- (RRBPalmSDKUserInternal *)user;

- (NSUInteger)numberOfPalms;

- (NSString *)cellTitleForPalmWithIndex:(NSUInteger)index;

- (NSString *)cellTitleForFeature:(RRBPalmSDKSettingsUserDataProviderFeatures)feature;

@end
