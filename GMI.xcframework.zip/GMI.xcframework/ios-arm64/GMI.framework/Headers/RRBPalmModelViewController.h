//
//  RRBPalmModelViewController.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 4/28/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, RRBPalmModelViewControllerUserAction) {
    RRBPalmModelViewControllerUserActionError,
    RRBPalmModelViewControllerUserActionAccept,
    RRBPalmModelViewControllerUserActionRetake,
    RRBPalmModelViewControllerUserActionClear,
    RRBPalmModelViewControllerUserActionCancel,
};

typedef void (^RRBPalmModelViewControllerCompletion)(RRBPalmModelViewControllerUserAction action, NSError *error);

@class RRBPalmSDKModelInfo;

@protocol RRBPalmSDKDecoder;

@interface RRBPalmModelViewController : UIViewController

@property (nonatomic, copy) RRBPalmModelViewControllerCompletion completionHandler;

// if not provided, palmDecoder instance created internally to extract mask image from model data
@property (nonatomic, strong) id<RRBPalmSDKDecoder> palmDecoder;

@property (nonatomic, strong) RRBPalmSDKModelInfo *modelInfo;

@end
