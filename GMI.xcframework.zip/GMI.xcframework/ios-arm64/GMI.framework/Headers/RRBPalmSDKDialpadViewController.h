//
//  RRBPalmSDKDialpadViewController.h
//  PalmSDK-iOS
//
//  Created by Serhiy Redko on 6/1/17.
//  Copyright © 2017 RedRock Biometrics. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef NS_ENUM(NSUInteger, RRBPalmSDKDialpadViewControllerControlKey)
{
    RRBPalmSDKDialpadViewControllerControlKeyDelete,
};

@class RRBPalmSDKDialpadSixPinViewController;
@class RRBPalmSDKDialpadFourPinViewController;

typedef void (^RRBPalmSDKDialpadViewControllerControlKeyHandler)(RRBPalmSDKDialpadViewControllerControlKey controlKey);
typedef void (^RRBPalmSDKDialpadViewControllerKeyHandler)(NSString *key);



@interface RRBPalmSDKDialpadViewController : UIViewController

@property (strong, nonatomic, readonly) IBOutlet RRBPalmSDKDialpadSixPinViewController *sixPinViewController;
@property (strong, nonatomic, readonly) IBOutlet RRBPalmSDKDialpadFourPinViewController *fourPinViewController;

@property (nonatomic, copy) RRBPalmSDKDialpadViewControllerControlKeyHandler controlKeyHandler;
@property (nonatomic, copy) RRBPalmSDKDialpadViewControllerKeyHandler keyHandler;

@end


